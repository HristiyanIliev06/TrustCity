﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace TrustCityWeb.Models;

public partial class Citizen
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("first_name")]
    [StringLength(30)]
    [Unicode(false)]
    public string FirstName { get; set; } = null!;

    [Column("last_name")]
    [StringLength(30)]
    [Unicode(false)]
    public string LastName { get; set; } = null!;

    [Column("email")]
    [StringLength(30)]
    [Unicode(false)]
    public string Email { get; set; } = null!;

    [InverseProperty("IdCitizensNavigation")]
    public virtual ICollection<ProjectsCitizensRelation> ProjectsCitizensRelations { get; set; } = new List<ProjectsCitizensRelation>();
}
