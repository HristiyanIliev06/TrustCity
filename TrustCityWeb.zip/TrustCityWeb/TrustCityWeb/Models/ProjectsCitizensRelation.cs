﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace TrustCityWeb.Models;

[Table("Projects_Citizens_Relations")]
public partial class ProjectsCitizensRelation
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("id_project")]
    public int IdProject { get; set; }

    [Column("id_citizens")]
    public int IdCitizens { get; set; }

    [ForeignKey("IdCitizens")]
    [InverseProperty("ProjectsCitizensRelations")]
    public virtual Citizen IdCitizensNavigation { get; set; } = null!;

    [ForeignKey("IdProject")]
    [InverseProperty("ProjectsCitizensRelations")]
    public virtual Project IdProjectNavigation { get; set; } = null!;
}
