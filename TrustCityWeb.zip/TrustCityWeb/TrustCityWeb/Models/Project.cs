﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace TrustCityWeb.Models;

public partial class Project
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Column("title")]
    [StringLength(30)]
    [Unicode(false)]
    public string Title { get; set; } = null!;

    [Column("monetary_goal", TypeName = "money")]
    public decimal MonetaryGoal { get; set; }

    [Column("description", TypeName = "text")]
    public string Description { get; set; } = null!;

    [Column("popularity")]
    public int Popularity { get; set; }

    [Column("date_of_publishing", TypeName = "datetime")]
    public DateTime DateOfPublishing { get; set; }

    [Column("duration_days")]
    public int DurationDays { get; set; }

    [Column("is_started")]
    public bool? IsStarted { get; set; }

    [InverseProperty("IdProjectNavigation")]
    public virtual ICollection<ProjectsCitizensRelation> ProjectsCitizensRelations { get; set; } = new List<ProjectsCitizensRelation>();
}
