﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using TrustCityWeb.Models;

namespace TrustCityWeb.Data;

public partial class TrustCityContext : DbContext
{
    public TrustCityContext()
    {
    }

    public TrustCityContext(DbContextOptions<TrustCityContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Citizen> Citizens { get; set; }

    public virtual DbSet<Project> Projects { get; set; }

    public virtual DbSet<ProjectsCitizensRelation> ProjectsCitizensRelations { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=DESKTOP-6CGBDLC;Initial catalog=TrustCity; trusted_connection=yes;TrustServerCertificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Citizen>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Citizens__3213E83FB865E1E8");

            entity.Property(e => e.Id).ValueGeneratedNever();
        });

        modelBuilder.Entity<Project>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Projects__3213E83F7BD79640");

            entity.Property(e => e.Id).ValueGeneratedNever();
        });

        modelBuilder.Entity<ProjectsCitizensRelation>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Projects__3213E83FE8D0CAD1");

            entity.Property(e => e.Id).ValueGeneratedNever();

            entity.HasOne(d => d.IdCitizensNavigation).WithMany(p => p.ProjectsCitizensRelations)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_projects_citizens_citizens");

            entity.HasOne(d => d.IdProjectNavigation).WithMany(p => p.ProjectsCitizensRelations)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_projects_citizens_projects");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
