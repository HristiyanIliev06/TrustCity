﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TrustCityWeb.Data;
using TrustCityWeb.Models;

namespace TrustCityWeb.Controllers
{
    public class ProjectsCitizensRelationsController : Controller
    {
        private readonly TrustCityContext _context;

        public ProjectsCitizensRelationsController(TrustCityContext context)
        {
            _context = context;
        }

        // GET: ProjectsCitizensRelations
        public async Task<IActionResult> Index()
        {
            var trustCityContext = _context.ProjectsCitizensRelations.Include(p => p.IdCitizensNavigation).Include(p => p.IdProjectNavigation);
            return View(await trustCityContext.ToListAsync());
        }

        // GET: ProjectsCitizensRelations/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var projectsCitizensRelation = await _context.ProjectsCitizensRelations
                .Include(p => p.IdCitizensNavigation)
                .Include(p => p.IdProjectNavigation)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (projectsCitizensRelation == null)
            {
                return NotFound();
            }

            return View(projectsCitizensRelation);
        }

        // GET: ProjectsCitizensRelations/Create
        public IActionResult Create()
        {
            ViewData["IdCitizens"] = new SelectList(_context.Citizens, "Id", "Id");
            ViewData["IdProject"] = new SelectList(_context.Projects, "Id", "Id");
            return View();
        }

        // POST: ProjectsCitizensRelations/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,IdProject,IdCitizens")] ProjectsCitizensRelation projectsCitizensRelation)
        {
            if (ModelState.IsValid)
            {
                _context.Add(projectsCitizensRelation);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCitizens"] = new SelectList(_context.Citizens, "Id", "Id", projectsCitizensRelation.IdCitizens);
            ViewData["IdProject"] = new SelectList(_context.Projects, "Id", "Id", projectsCitizensRelation.IdProject);
            return View(projectsCitizensRelation);
        }

        // GET: ProjectsCitizensRelations/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var projectsCitizensRelation = await _context.ProjectsCitizensRelations.FindAsync(id);
            if (projectsCitizensRelation == null)
            {
                return NotFound();
            }
            ViewData["IdCitizens"] = new SelectList(_context.Citizens, "Id", "Id", projectsCitizensRelation.IdCitizens);
            ViewData["IdProject"] = new SelectList(_context.Projects, "Id", "Id", projectsCitizensRelation.IdProject);
            return View(projectsCitizensRelation);
        }

        // POST: ProjectsCitizensRelations/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,IdProject,IdCitizens")] ProjectsCitizensRelation projectsCitizensRelation)
        {
            if (id != projectsCitizensRelation.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(projectsCitizensRelation);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProjectsCitizensRelationExists(projectsCitizensRelation.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["IdCitizens"] = new SelectList(_context.Citizens, "Id", "Id", projectsCitizensRelation.IdCitizens);
            ViewData["IdProject"] = new SelectList(_context.Projects, "Id", "Id", projectsCitizensRelation.IdProject);
            return View(projectsCitizensRelation);
        }

        // GET: ProjectsCitizensRelations/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var projectsCitizensRelation = await _context.ProjectsCitizensRelations
                .Include(p => p.IdCitizensNavigation)
                .Include(p => p.IdProjectNavigation)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (projectsCitizensRelation == null)
            {
                return NotFound();
            }

            return View(projectsCitizensRelation);
        }

        // POST: ProjectsCitizensRelations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var projectsCitizensRelation = await _context.ProjectsCitizensRelations.FindAsync(id);
            if (projectsCitizensRelation != null)
            {
                _context.ProjectsCitizensRelations.Remove(projectsCitizensRelation);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProjectsCitizensRelationExists(int id)
        {
            return _context.ProjectsCitizensRelations.Any(e => e.Id == id);
        }
    }
}
